<!DOCTYPE html>
<html lang="en" xmlns:fb="http://ogp.me/ns/fb#">
	<head>
		<title>Diet and Training Tips | Strength Coach - Strength Coach Glasgow</title><meta property="og:site_name" content="Strength Coach Glasgow" />
<meta property="og:title" content="Category: Exercises" />
<meta property="og:description" content="The side plank is a great core exercise as it forces the lateral stabilisers of the body like the oblique’s and glutes to work hard to maintain stability and alignment through the body. When you..." />
<meta property="og:image" content="http://www.strengthcoachglasgow.co.uk/uploads/1/2/3/3/123320581/exercisespotlightsideplank_orig.png" />
<meta property="og:image" content="http://www.strengthcoachglasgow.co.uk/uploads/1/2/3/3/123320581/exercisespotlightsnatch_orig.png" />
<meta property="og:image" content="http://www.strengthcoachglasgow.co.uk/uploads/1/2/3/3/123320581/exercisespotlightstandinglongjump_orig.png" />
<meta property="og:image" content="http://www.strengthcoachglasgow.co.uk/uploads/1/2/3/3/123320581/exercisespotlightwalkinglunge_orig.png" />
<meta property="og:image" content="http://www.strengthcoachglasgow.co.uk/uploads/1/2/3/3/123320581/exercisespotlightalekna_orig.png" />
<meta property="og:image" content="http://www.strengthcoachglasgow.co.uk/uploads/1/2/3/3/123320581/exercisespotlightdeadbug_orig.png" />
<meta property="og:image" content="http://www.strengthcoachglasgow.co.uk/uploads/1/2/3/3/123320581/exercisespotlightboxsquat_orig.png" />
<meta property="og:image" content="http://www.strengthcoachglasgow.co.uk/uploads/1/2/3/3/123320581/exercisespotlightpushpress_orig.png" />
<meta property="og:image" content="http://www.strengthcoachglasgow.co.uk/uploads/1/2/3/3/123320581/exercisespotlightseateddbpress_orig.png" />
<meta property="og:image" content="http://www.strengthcoachglasgow.co.uk/uploads/1/2/3/3/123320581/exercisespotlightchin-upnegative_orig.png" />
<meta property="og:url" content="http://www.strengthcoachglasgow.co.uk/1/category/exercises" />
<meta http-equiv='cache-control' content='no-cache' />


<meta name="keywords" content="diet tips, nutrition tips, fitness blog, workout tips, training advice, lifestyle plan" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

		<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '350875128635203');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=350875128635203&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-131269023-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-131269023-1');
</script>
		<link id="wsite-base-style" rel="stylesheet" type="text/css" href="//cdn2.editmysite.com/css/sites.css?buildTime=1640035830" />
<link rel="stylesheet" type="text/css" href="//cdn2.editmysite.com/css/old/fancybox.css?1624645395" />
<link rel="stylesheet" type="text/css" href="//cdn2.editmysite.com/css/social-icons.css?buildtime=1624645395" media="screen,projection" />
<link rel="stylesheet" type="text/css" href="/files/main_style.css?1624892374" title="wsite-theme-css" />
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700&subset=latin,latin-ext' rel='stylesheet' type='text/css' />

<link href='//fonts.googleapis.com/css?family=Karla:400,700,400italic,700italic&subset=latin,latin-ext' rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Oswald:400,300,700&subset=latin,latin-ext' rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Oswald:400,300,700&subset=latin,latin-ext' rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Karla:400,700,400italic,700italic&subset=latin,latin-ext' rel='stylesheet' type='text/css' />
<style type='text/css'>
.wsite-elements.wsite-not-footer:not(.wsite-header-elements) div.paragraph, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) p, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .product-block .product-title, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .product-description, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .wsite-form-field label, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .wsite-form-field label, #wsite-content div.paragraph, #wsite-content p, #wsite-content .product-block .product-title, #wsite-content .product-description, #wsite-content .wsite-form-field label, #wsite-content .wsite-form-field label, .blog-sidebar div.paragraph, .blog-sidebar p, .blog-sidebar .wsite-form-field label, .blog-sidebar .wsite-form-field label {font-family:"Karla" !important;}
#wsite-content div.paragraph, #wsite-content p, #wsite-content .product-block .product-title, #wsite-content .product-description, #wsite-content .wsite-form-field label, #wsite-content .wsite-form-field label, .blog-sidebar div.paragraph, .blog-sidebar p, .blog-sidebar .wsite-form-field label, .blog-sidebar .wsite-form-field label {color:#2a2a2a !important;}
.wsite-elements.wsite-footer div.paragraph, .wsite-elements.wsite-footer p, .wsite-elements.wsite-footer .product-block .product-title, .wsite-elements.wsite-footer .product-description, .wsite-elements.wsite-footer .wsite-form-field label, .wsite-elements.wsite-footer .wsite-form-field label{}
.wsite-elements.wsite-not-footer:not(.wsite-header-elements) h2, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .product-long .product-title, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .product-large .product-title, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .product-small .product-title, #wsite-content h2, #wsite-content .product-long .product-title, #wsite-content .product-large .product-title, #wsite-content .product-small .product-title, .blog-sidebar h2 {font-family:"Oswald" !important;font-style:italic !important;text-transform:  uppercase !important;}
#wsite-content h2, #wsite-content .product-long .product-title, #wsite-content .product-large .product-title, #wsite-content .product-small .product-title, .blog-sidebar h2 {color:#2a2a2a !important;}
.wsite-elements.wsite-footer h2, .wsite-elements.wsite-footer .product-long .product-title, .wsite-elements.wsite-footer .product-large .product-title, .wsite-elements.wsite-footer .product-small .product-title{}
#wsite-title {}
.wsite-menu-default a {}
.wsite-menu a {}
.wsite-image div, .wsite-caption {}
.galleryCaptionInnerText {}
.fancybox-title {}
.wslide-caption-text {}
.wsite-phone {}
.wsite-headline,.wsite-header-section .wsite-content-title {font-family:"Oswald" !important;font-weight:700 !important;color:#fff !important;font-style:italic !important;text-transform:  uppercase !important;letter-spacing: -3px !important;}
.wsite-headline-paragraph,.wsite-header-section .paragraph {font-family:"Karla" !important;text-transform:  uppercase !important;letter-spacing: 0px !important;}
.wsite-button-inner {}
.wsite-not-footer blockquote {}
.wsite-footer blockquote {}
.blog-header h2 a {}
#wsite-content h2.wsite-product-title {}
.wsite-product .wsite-product-price a {}
@media screen and (min-width: 767px) {.wsite-elements.wsite-not-footer:not(.wsite-header-elements) div.paragraph, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) p, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .product-block .product-title, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .product-description, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .wsite-form-field label, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .wsite-form-field label, #wsite-content div.paragraph, #wsite-content p, #wsite-content .product-block .product-title, #wsite-content .product-description, #wsite-content .wsite-form-field label, #wsite-content .wsite-form-field label, .blog-sidebar div.paragraph, .blog-sidebar p, .blog-sidebar .wsite-form-field label, .blog-sidebar .wsite-form-field label {}
#wsite-content div.paragraph, #wsite-content p, #wsite-content .product-block .product-title, #wsite-content .product-description, #wsite-content .wsite-form-field label, #wsite-content .wsite-form-field label, .blog-sidebar div.paragraph, .blog-sidebar p, .blog-sidebar .wsite-form-field label, .blog-sidebar .wsite-form-field label {}
.wsite-elements.wsite-footer div.paragraph, .wsite-elements.wsite-footer p, .wsite-elements.wsite-footer .product-block .product-title, .wsite-elements.wsite-footer .product-description, .wsite-elements.wsite-footer .wsite-form-field label, .wsite-elements.wsite-footer .wsite-form-field label{}
.wsite-elements.wsite-not-footer:not(.wsite-header-elements) h2, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .product-long .product-title, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .product-large .product-title, .wsite-elements.wsite-not-footer:not(.wsite-header-elements) .product-small .product-title, #wsite-content h2, #wsite-content .product-long .product-title, #wsite-content .product-large .product-title, #wsite-content .product-small .product-title, .blog-sidebar h2 {font-size:37px !important;}
#wsite-content h2, #wsite-content .product-long .product-title, #wsite-content .product-large .product-title, #wsite-content .product-small .product-title, .blog-sidebar h2 {}
.wsite-elements.wsite-footer h2, .wsite-elements.wsite-footer .product-long .product-title, .wsite-elements.wsite-footer .product-large .product-title, .wsite-elements.wsite-footer .product-small .product-title{}
#wsite-title {font-size:19px !important;}
.wsite-menu-default a {}
.wsite-menu a {}
.wsite-image div, .wsite-caption {}
.galleryCaptionInnerText {}
.fancybox-title {}
.wslide-caption-text {}
.wsite-phone {}
.wsite-headline,.wsite-header-section .wsite-content-title {font-size:80px !important;}
.wsite-headline-paragraph,.wsite-header-section .paragraph {font-size:22px !important;line-height:34px !important;}
.wsite-button-inner {}
.wsite-not-footer blockquote {}
.wsite-footer blockquote {}
.blog-header h2 a {}
#wsite-content h2.wsite-product-title {}
.wsite-product .wsite-product-price a {}
}</style>

		<script src='/files/templateArtifacts.js?1624892374'></script>
<script>
var STATIC_BASE = '//cdn1.editmysite.com/';
var ASSETS_BASE = '//cdn2.editmysite.com/';
var STYLE_PREFIX = 'wsite';
</script>
<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js'></script>

<script type="text/javascript" src="//cdn2.editmysite.com/js/lang/en/stl.js?buildTime=1624645395&"></script>
<script src="//cdn2.editmysite.com/js/site/main.js?buildTime=1640035830"></script><script type="text/javascript">
		function initCustomerAccountsModels() {
					(function(){_W.setup_rpc({"url":"\/ajax\/api\/JsonRPC\/CustomerAccounts\/","actions":{"CustomerAccounts":[{"name":"login","len":2,"multiple":false,"standalone":false},{"name":"logout","len":0,"multiple":false,"standalone":false},{"name":"getSessionDetails","len":0,"multiple":false,"standalone":false},{"name":"getAccountDetails","len":0,"multiple":false,"standalone":false},{"name":"getOrders","len":0,"multiple":false,"standalone":false},{"name":"register","len":4,"multiple":false,"standalone":false},{"name":"emailExists","len":1,"multiple":false,"standalone":false},{"name":"passwordReset","len":1,"multiple":false,"standalone":false},{"name":"passwordUpdate","len":3,"multiple":false,"standalone":false},{"name":"validateSession","len":1,"multiple":false,"standalone":false}]},"namespace":"_W.CustomerAccounts.RPC"});
_W.setup_model_rpc({"rpc_namespace":"_W.CustomerAccounts.RPC","model_namespace":"_W.CustomerAccounts.BackboneModelData","collection_namespace":"_W.CustomerAccounts.BackboneCollectionData","bootstrap_namespace":"_W.CustomerAccounts.BackboneBootstrap","models":{"CustomerAccounts":{"_class":"CustomerAccounts.Model.CustomerAccounts","defaults":null,"validation":null,"types":null,"idAttribute":null,"keydefs":null}},"collections":{"CustomerAccounts":{"_class":"CustomerAccounts.Collection.CustomerAccounts"}},"bootstrap":[]});
})();
		}
		if(document.createEvent && document.addEventListener) {
			var initEvt = document.createEvent('Event');
			initEvt.initEvent('customerAccountsModelsInitialized', true, false);
			document.dispatchEvent(initEvt);
		} else if(document.documentElement.initCustomerAccountsModels === 0){
			document.documentElement.initCustomerAccountsModels++
		}
		</script>
		<script type="text/javascript"> _W = _W || {}; _W.securePrefix='www.strengthcoachglasgow.co.uk'; </script><script>_W = _W || {};
			_W.customerLocale = "en";
			_W.storeName = null;
			_W.isCheckoutReskin = false;
			_W.storeCountry = "TH";
			_W.storeCurrency = "THB";
			_W.storeEuPrivacyPolicyUrl = "";
			com_currentSite = "540203683522207150";
			com_userID = "123320581";</script><script type="text/javascript">_W.resellerSite = true;</script><script type="text/javascript">_W.configDomain = "www.weebly.com";</script><script>_W.relinquish && _W.relinquish()</script>
<script type="text/javascript" src="//cdn2.editmysite.com/js/lang/en/stl.js?buildTime=1640035830&"></script><script> _W.themePlugins = [];</script><script type="text/javascript"> _W.recaptchaUrl = "https://www.google.com/recaptcha/api.js"; </script><script type="text/javascript"><!--
	
	
	function initFlyouts(){
		initPublishedFlyoutMenus(
			[{"id":"819301532588520220","title":"Home","url":"index.html","target":"","nav_menu":false,"nonclickable":false},{"id":"563831931702132542","title":"About","url":"about.html","target":"","nav_menu":false,"nonclickable":false},{"id":"212032923499255978","title":"Programs","url":"programs.html","target":"","nav_menu":false,"nonclickable":true},{"id":"495204845769764285","title":"Success Stories","url":"success-stories.html","target":"","nav_menu":false,"nonclickable":false},{"id":"166172616511975132","title":"Contact","url":"contact.html","target":"","nav_menu":false,"nonclickable":false},{"id":"815468006538632597","title":"Blog","url":"blog.html","target":"","nav_menu":false,"nonclickable":false}],
			"815468006538632597",
			'',
			'active',
			false,
			{"navigation\/item":"<li {{#id}}id=\"{{id}}\"{{\/id}} class=\"wsite-menu-item-wrap\">\n\t<a\n\t\t{{^nonclickable}}\n\t\t\t{{^nav_menu}}\n\t\t\t\thref=\"{{url}}\"\n\t\t\t{{\/nav_menu}}\n\t\t{{\/nonclickable}}\n\t\t{{#target}}\n\t\t\ttarget=\"{{target}}\"\n\t\t{{\/target}}\n\t\t{{#membership_required}}\n\t\t\tdata-membership-required=\"{{.}}\"\n\t\t{{\/membership_required}}\n\t\tclass=\"wsite-menu-item\"\n\t\t>\n\t\t{{{title_html}}}\n\t<\/a>\n\t{{#has_children}}{{> navigation\/flyout\/list}}{{\/has_children}}\n<\/li>\n","navigation\/flyout\/list":"<div class=\"wsite-menu-wrap\" style=\"display:none\">\n\t<ul class=\"wsite-menu\">\n\t\t{{#children}}{{> navigation\/flyout\/item}}{{\/children}}\n\t<\/ul>\n<\/div>\n","navigation\/flyout\/item":"<li {{#id}}id=\"{{id}}\"{{\/id}}\n\tclass=\"wsite-menu-subitem-wrap {{#is_current}}wsite-nav-current{{\/is_current}}\"\n\t>\n\t<a\n\t\t{{^nonclickable}}\n\t\t\t{{^nav_menu}}\n\t\t\t\thref=\"{{url}}\"\n\t\t\t{{\/nav_menu}}\n\t\t{{\/nonclickable}}\n\t\t{{#target}}\n\t\t\ttarget=\"{{target}}\"\n\t\t{{\/target}}\n\t\tclass=\"wsite-menu-subitem\"\n\t\t>\n\t\t<span class=\"wsite-menu-title\">\n\t\t\t{{{title_html}}}\n\t\t<\/span>{{#has_children}}<span class=\"wsite-menu-arrow\">&gt;<\/span>{{\/has_children}}\n\t<\/a>\n\t{{#has_children}}{{> navigation\/flyout\/list}}{{\/has_children}}\n<\/li>\n"},
			{}
		)
	}
//-->
</script>
		
		
	</head>
	<body class="header-page  wsite-page-blog wsite-blog-index  full-width-body-off header-overlay-on alt-nav-on  wsite-theme-light"><div class="wrapper">
    <div class="birdseye-header">
      <div class="nav-wrap">
        <div class="container">
          <div class="logo"><span class="wsite-logo">

	<a href="/">
		<img src="/uploads/1/2/3/3/123320581/strength-coach-glas-logo-final-transparent.png" alt="Strength Coach Glasgow" />
	</a>

</span></div>
          <div class="nav desktop-nav"><ul class="wsite-menu-default">
		<li id="pg819301532588520220" class="wsite-menu-item-wrap">
			<a
						href="/"
				class="wsite-menu-item"
				>
				Home
			</a>
			
		</li>
		<li id="pg563831931702132542" class="wsite-menu-item-wrap">
			<a
						href="/about.html"
				class="wsite-menu-item"
				>
				About
			</a>
			
		</li>
		<li id="pg212032923499255978" class="wsite-menu-item-wrap">
			<a
				class="wsite-menu-item"
				>
				Programs
			</a>
			<div class="wsite-menu-wrap" style="display:none">
	<ul class="wsite-menu">
		<li id="wsite-nav-876530741345501780"
	class="wsite-menu-subitem-wrap "
	>
	<a
				href="/personal-training.html"
		class="wsite-menu-subitem"
		>
		<span class="wsite-menu-title">
			Personal Training
		</span>
	</a>
	
</li>
<li id="wsite-nav-462203199864741067"
	class="wsite-menu-subitem-wrap "
	>
	<a
				href="/online-training.html"
		class="wsite-menu-subitem"
		>
		<span class="wsite-menu-title">
			Online Training
		</span>
	</a>
	
</li>

	</ul>
</div>

		</li>
		<li id="pg495204845769764285" class="wsite-menu-item-wrap">
			<a
						href="/success-stories.html"
				class="wsite-menu-item"
				>
				Success Stories
			</a>
			
		</li>
		<li id="pg166172616511975132" class="wsite-menu-item-wrap">
			<a
						href="/contact.html"
				class="wsite-menu-item"
				>
				Contact
			</a>
			
		</li>
		<li id="active" class="wsite-menu-item-wrap">
			<a
						href="/blog.html"
				class="wsite-menu-item"
				>
				Blog
			</a>
			
		</li>
</ul>
</div>
          <a class="hamburger" aria-label="Menu" href="#"><span></span></a>
        </div>
      </div>
    </div>

    <div class="banner-wrap">
      <div class="wsite-elements wsite-not-footer wsite-header-elements">
	<div class="wsite-section-wrap">
	<div  class="wsite-section wsite-header-section wsite-section-bg-image wsite-section-effect-parallax" style="height: auto;background-image: url(&quot;/uploads/1/2/3/3/123320581/background-images/1565318044.jpg&quot;) ;background-repeat: no-repeat ;background-position: 50% 50% ;background-size: 100% ;background-color: transparent ;background-size: cover;background-attachment: fixed;" >
		<div class="wsite-section-content">
			
          <div class="container">
            <div class="banner">
				<div class="wsite-section-elements">
					<div class="wsite-spacer" style="height:50px;"></div>

<h2 class="wsite-content-title">Strength Coach Glasgow Personal training tips</h2>

<div class="wsite-spacer" style="height:50px;"></div>
				</div>
			</div>
          </div>
      
		</div>
		<div class=""></div>
	</div>
</div>

</div>

    </div>

    <div class="main-wrap">
      <div class="wsite-section-content">
          <div class="container"><div class="wsite-elements wsite-not-footer">
	<table 
	id="blogTable" 
		class="wsite-not-footer" 
	style="border: 0; width: 100%; table-layout: fixed" 
>
	<tr>
	    <td valign="top">
	        	<div id="815468006538632597-blog" class="blog-body" style="float: left;"> 
		<div id="wsite-content">	<div id="blog-post-448795784804663278" class="blog-post">
	
	
		<div class="blog-header">
			<h2 class="blog-title">
					<a class="blog-title-link blog-link" href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-side-plank">Exercise Spotlight – Side Plank</a>

			</h2>
			<p class="blog-date">
					<span class="date-text">
		7/20/2020
	</span>

			</p>
			<p class="blog-comments">
				
			</p>
		</div>
	
		<div class="blog-separator">&nbsp;</div>
	
		<div class="blog-content">
				
<div><div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center"> <a> <img src="/uploads/1/2/3/3/123320581/exercisespotlightsideplank_orig.png" alt="Picture" style="width:auto;max-width:100%"></a> <div style="display:block;font-size:90%"></div> </div></div>  <div class="paragraph">The side plank is a great core exercise as it forces the lateral stabilisers of the body like the oblique&rsquo;s and glutes to work hard to maintain stability and alignment through the body. When you swap sides it will also highlight any deficiencies or weaknesses that may be present from side to side.&nbsp;<br></div>
<br/>
		<div class="blog-read-more">
			<a href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-side-plank" class="blog-link">Read More</a>
		</div>

		</div>
	
	
			<div class="blog-social  ">
		<div class="blog-social-item blog-fb-like"><fb:like href="https://www.strengthcoachglasgow.co.uk/1/post/2020/07/exercise-spotlight-side-plank.html" width="90" layout="button_count" action="like" show_faces="false" share="false"></fb:like></div><div class="blog-social-item"><a class="twitter-share-button" href="http://twitter.com/share?url=https://www.strengthcoachglasgow.co.uk/1/post/2020/07/exercise-spotlight-side-plank.html" data-text="Exercise Spotlight – Side Plank - Strength Coach Glasgow" data-count="horizontal"></a></div>
		<div style="clear:both"></div>
	</div>

	
		<div class="blog-comments-bottom">
			
		</div>
	
		<div class="blog-post-separator"></div>
	</div>	<div id="blog-post-786537147755437014" class="blog-post">
	
	
		<div class="blog-header">
			<h2 class="blog-title">
					<a class="blog-title-link blog-link" href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-snatch">Exercise Spotlight – Snatch</a>

			</h2>
			<p class="blog-date">
					<span class="date-text">
		7/14/2020
	</span>

			</p>
			<p class="blog-comments">
				
			</p>
		</div>
	
		<div class="blog-separator">&nbsp;</div>
	
		<div class="blog-content">
				
<div><div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0px;margin-right:0px;text-align:center"> <a> <img src="/uploads/1/2/3/3/123320581/exercisespotlightsnatch_orig.png" alt="learn to snatch with strength coach glasgow personal training service" style="width:auto;max-width:100%"></a> <div style="display:block;font-size:90%"></div> </div></div>  <div class="paragraph">The Snatch is one of the Olympic Weight Lifting movements and is in my opinion the most technical single move that you can perform with a barbell. It is built on the foundations of the overhead squat and although it can be taught safely to beginners with the right instruction, I&rsquo;ve marked this as an advanced exercise as you should have some level of strength and experience with resistance training before giving it a go.<br></div>
<br/>
		<div class="blog-read-more">
			<a href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-snatch" class="blog-link">Read More</a>
		</div>

		</div>
	
	
			<div class="blog-social  ">
		<div class="blog-social-item blog-fb-like"><fb:like href="https://www.strengthcoachglasgow.co.uk/1/post/2020/07/exercise-spotlight-snatch.html" width="90" layout="button_count" action="like" show_faces="false" share="false"></fb:like></div><div class="blog-social-item"><a class="twitter-share-button" href="http://twitter.com/share?url=https://www.strengthcoachglasgow.co.uk/1/post/2020/07/exercise-spotlight-snatch.html" data-text="Exercise Spotlight – Snatch - Strength Coach Glasgow" data-count="horizontal"></a></div>
		<div style="clear:both"></div>
	</div>

	
		<div class="blog-comments-bottom">
			
		</div>
	
		<div class="blog-post-separator"></div>
	</div>	<div id="blog-post-930092704430664617" class="blog-post">
	
	
		<div class="blog-header">
			<h2 class="blog-title">
					<a class="blog-title-link blog-link" href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-standing-long-jump-broad-jump">Exercise Spotlight – Standing Long Jump (Broad Jump)</a>

			</h2>
			<p class="blog-date">
					<span class="date-text">
		7/7/2020
	</span>

			</p>
			<p class="blog-comments">
				
			</p>
		</div>
	
		<div class="blog-separator">&nbsp;</div>
	
		<div class="blog-content">
				
<div><div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0px;margin-right:0px;text-align:center"> <a> <img src="/uploads/1/2/3/3/123320581/exercisespotlightstandinglongjump_orig.png" alt="jumping power exercise demonstration by strength coach glasgow personal trainer" style="width:auto;max-width:100%"></a> <div style="display:block;font-size:90%"></div> </div></div>  <div class="paragraph">The broad jump or standing long jump is an introductory plyometric exercise that can help improve explosive power. Although it is introductory plyometrics, I&rsquo;ve categorised this as being advanced because you need to have some strong legs to control the landings for this one. You should already be very comfortable squatting and should be able to at least squat your own bodyweight before considering this as an explosive power exercise choice.&nbsp;</div>
<br/>
		<div class="blog-read-more">
			<a href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-standing-long-jump-broad-jump" class="blog-link">Read More</a>
		</div>

		</div>
	
	
			<div class="blog-social  ">
		<div class="blog-social-item blog-fb-like"><fb:like href="https://www.strengthcoachglasgow.co.uk/1/post/2020/07/exercise-spotlight-standing-long-jump-broad-jump.html" width="90" layout="button_count" action="like" show_faces="false" share="false"></fb:like></div><div class="blog-social-item"><a class="twitter-share-button" href="http://twitter.com/share?url=https://www.strengthcoachglasgow.co.uk/1/post/2020/07/exercise-spotlight-standing-long-jump-broad-jump.html" data-text="Exercise Spotlight – Standing Long Jump (Broad Jump) - Strength Coach Glasgow" data-count="horizontal"></a></div>
		<div style="clear:both"></div>
	</div>

	
		<div class="blog-comments-bottom">
			
		</div>
	
		<div class="blog-post-separator"></div>
	</div>	<div id="blog-post-938455646210766732" class="blog-post">
	
	
		<div class="blog-header">
			<h2 class="blog-title">
					<a class="blog-title-link blog-link" href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-walking-lunge">Exercise Spotlight – Walking Lunge</a>

			</h2>
			<p class="blog-date">
					<span class="date-text">
		6/30/2020
	</span>

			</p>
			<p class="blog-comments">
				
			</p>
		</div>
	
		<div class="blog-separator">&nbsp;</div>
	
		<div class="blog-content">
				
<div><div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0px;margin-right:0px;text-align:center"> <a> <img src="/uploads/1/2/3/3/123320581/exercisespotlightwalkinglunge_orig.png" alt="walking lunge quad exercise by strength coach glasgow personal training provider" style="width:auto;max-width:100%"></a> <div style="display:block;font-size:90%"></div> </div></div>  <div class="paragraph">The walking lunge is a fantastic lower body option for improving leg strength in a manner than transfers to many life and sporting contexts. The nature of transferring weight from one leg to the other through periods of being on only 1 leg for support mimics exactly the demands of walking and running. Good lunging technique and strength will help you walk, run, jump and generally be a lot more stable through your lower body.<br></div>
<br/>
		<div class="blog-read-more">
			<a href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-walking-lunge" class="blog-link">Read More</a>
		</div>

		</div>
	
	
			<div class="blog-social  ">
		<div class="blog-social-item blog-fb-like"><fb:like href="https://www.strengthcoachglasgow.co.uk/1/post/2020/06/exercise-spotlight-walking-lunge.html" width="90" layout="button_count" action="like" show_faces="false" share="false"></fb:like></div><div class="blog-social-item"><a class="twitter-share-button" href="http://twitter.com/share?url=https://www.strengthcoachglasgow.co.uk/1/post/2020/06/exercise-spotlight-walking-lunge.html" data-text="Exercise Spotlight – Walking Lunge - Strength Coach Glasgow" data-count="horizontal"></a></div>
		<div style="clear:both"></div>
	</div>

	
		<div class="blog-comments-bottom">
			
		</div>
	
		<div class="blog-post-separator"></div>
	</div>	<div id="blog-post-762066311422929376" class="blog-post">
	
	
		<div class="blog-header">
			<h2 class="blog-title">
					<a class="blog-title-link blog-link" href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-alekna">Exercise Spotlight – Alekna</a>

			</h2>
			<p class="blog-date">
					<span class="date-text">
		6/23/2020
	</span>

			</p>
			<p class="blog-comments">
				
			</p>
		</div>
	
		<div class="blog-separator">&nbsp;</div>
	
		<div class="blog-content">
				
<div><div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0px;margin-right:0px;text-align:center"> <a> <img src="/uploads/1/2/3/3/123320581/exercisespotlightalekna_orig.png" alt="alekna core exercise idea by strength coach glasgow personal trainer" style="width:auto;max-width:100%"></a> <div style="display:block;font-size:90%"></div> </div></div>  <div class="paragraph">The Alekna, named after a discus athlete, is a similar core exercise to the deadbug but is much greater in difficulty. It is a great option for training your core to work to maintain stability through your spine as you transfer force and movements through your legs and arms &ndash; exactly the way your core should be working. It is still a good option for beginners as you have the ground to use as feedback against your back but if you are a total beginner you should start with the deadbug before progressing.</div>
<br/>
		<div class="blog-read-more">
			<a href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-alekna" class="blog-link">Read More</a>
		</div>

		</div>
	
	
			<div class="blog-social  ">
		<div class="blog-social-item blog-fb-like"><fb:like href="https://www.strengthcoachglasgow.co.uk/1/post/2020/06/exercise-spotlight-alekna.html" width="90" layout="button_count" action="like" show_faces="false" share="false"></fb:like></div><div class="blog-social-item"><a class="twitter-share-button" href="http://twitter.com/share?url=https://www.strengthcoachglasgow.co.uk/1/post/2020/06/exercise-spotlight-alekna.html" data-text="Exercise Spotlight – Alekna - Strength Coach Glasgow" data-count="horizontal"></a></div>
		<div style="clear:both"></div>
	</div>

	
		<div class="blog-comments-bottom">
			
		</div>
	
		<div class="blog-post-separator"></div>
	</div>	<div id="blog-post-409189445336276703" class="blog-post">
	
	
		<div class="blog-header">
			<h2 class="blog-title">
					<a class="blog-title-link blog-link" href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-deadbug">Exercise Spotlight – Deadbug</a>

			</h2>
			<p class="blog-date">
					<span class="date-text">
		6/16/2020
	</span>

			</p>
			<p class="blog-comments">
				
			</p>
		</div>
	
		<div class="blog-separator">&nbsp;</div>
	
		<div class="blog-content">
				
<div><div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center"> <a> <img src="/uploads/1/2/3/3/123320581/exercisespotlightdeadbug_orig.png" alt="Picture" style="width:auto;max-width:100%"></a> <div style="display:block;font-size:90%"></div> </div></div>  <div class="paragraph">The deadbug is a great core and ab exercise when executed with correct technique and control. It is a good starting point for raising awareness of the core and a neutral spine as you have the floor to brace your back against and use as feedback. Take care to use slow controlled movements and you can integrate the breath as you move too to learn how the breathing can help create tension and stability around your spine.<br></div>
<br/>
		<div class="blog-read-more">
			<a href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-deadbug" class="blog-link">Read More</a>
		</div>

		</div>
	
	
			<div class="blog-social  ">
		<div class="blog-social-item blog-fb-like"><fb:like href="https://www.strengthcoachglasgow.co.uk/1/post/2020/06/exercise-spotlight-deadbug.html" width="90" layout="button_count" action="like" show_faces="false" share="false"></fb:like></div><div class="blog-social-item"><a class="twitter-share-button" href="http://twitter.com/share?url=https://www.strengthcoachglasgow.co.uk/1/post/2020/06/exercise-spotlight-deadbug.html" data-text="Exercise Spotlight – Deadbug - Strength Coach Glasgow" data-count="horizontal"></a></div>
		<div style="clear:both"></div>
	</div>

	
		<div class="blog-comments-bottom">
			
		</div>
	
		<div class="blog-post-separator"></div>
	</div>	<div id="blog-post-171040433257715367" class="blog-post">
	
	
		<div class="blog-header">
			<h2 class="blog-title">
					<a class="blog-title-link blog-link" href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-box-squat">Exercise Spotlight – Box Squat</a>

			</h2>
			<p class="blog-date">
					<span class="date-text">
		6/9/2020
	</span>

			</p>
			<p class="blog-comments">
				
			</p>
		</div>
	
		<div class="blog-separator">&nbsp;</div>
	
		<div class="blog-content">
				
<div><div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0px;margin-right:0px;text-align:center"> <a> <img src="/uploads/1/2/3/3/123320581/exercisespotlightboxsquat_orig.png" alt="Box Squat exercise demo by glasgow personal trainer strength coach glasgow" style="width:auto;max-width:100%"></a> <div style="display:block;font-size:90%"></div> </div></div>  <div class="paragraph">The box squat has a variety of uses within a training program. I most often find myself using it when teaching beginners to squat with the barbell but they struggle to get the same depth as when using a kettlebell for goblet squat. It gives you a target to sit onto and to make sure you hit depth meaning that you develop consistent technique but also have the extra confidence of the box to aim for. Start the box at the height you can get to comfortably and as your skill and confidence grows, take height off the box so that it gets lower over time. Once you can consistently hit your required squat depth then you can take the box away and try free back squat.<br></div>
<br/>
		<div class="blog-read-more">
			<a href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-box-squat" class="blog-link">Read More</a>
		</div>

		</div>
	
	
			<div class="blog-social  ">
		<div class="blog-social-item blog-fb-like"><fb:like href="https://www.strengthcoachglasgow.co.uk/1/post/2020/06/exercise-spotlight-box-squat.html" width="90" layout="button_count" action="like" show_faces="false" share="false"></fb:like></div><div class="blog-social-item"><a class="twitter-share-button" href="http://twitter.com/share?url=https://www.strengthcoachglasgow.co.uk/1/post/2020/06/exercise-spotlight-box-squat.html" data-text="Exercise Spotlight – Box Squat - Strength Coach Glasgow" data-count="horizontal"></a></div>
		<div style="clear:both"></div>
	</div>

	
		<div class="blog-comments-bottom">
			
		</div>
	
		<div class="blog-post-separator"></div>
	</div>	<div id="blog-post-827720159138932291" class="blog-post">
	
	
		<div class="blog-header">
			<h2 class="blog-title">
					<a class="blog-title-link blog-link" href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-push-press">Exercise Spotlight – Push Press</a>

			</h2>
			<p class="blog-date">
					<span class="date-text">
		5/15/2020
	</span>

			</p>
			<p class="blog-comments">
				
			</p>
		</div>
	
		<div class="blog-separator">&nbsp;</div>
	
		<div class="blog-content">
				
<div><div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0px;margin-right:0px;text-align:center"> <a> <img src="/uploads/1/2/3/3/123320581/exercisespotlightpushpress_orig.png" alt="Push press barbell exercise technique by strength coach glasgow personal trainer" style="width:auto;max-width:100%"></a> <div style="display:block;font-size:90%"></div> </div></div>  <div class="paragraph">The Push Press is a full body explosive lift. You can start to handle heavier weights overhead which gives greater overload than you might be able to achieve with just shoulder power alone. It also gives the opportunity to develop rate of force development as you skilfully try to accelerate the weight overhead! If you are an overhead or power-based athlete then the overhead press is perfect for improving power. It is essentially a more advanced version of the strict press and so is a great skill to start to develop to take your general strength training to the next level. Make sure you have mastered the strict overhead press before attempting this. It is a staple for Weightlifters to improve their overhead strength but it is also very useful for developing power that will transfer into jumping and throwing based movements.&nbsp;</div>
<br/>
		<div class="blog-read-more">
			<a href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-push-press" class="blog-link">Read More</a>
		</div>

		</div>
	
	
			<div class="blog-social  ">
		<div class="blog-social-item blog-fb-like"><fb:like href="https://www.strengthcoachglasgow.co.uk/1/post/2020/05/exercise-spotlight-push-press.html" width="90" layout="button_count" action="like" show_faces="false" share="false"></fb:like></div><div class="blog-social-item"><a class="twitter-share-button" href="http://twitter.com/share?url=https://www.strengthcoachglasgow.co.uk/1/post/2020/05/exercise-spotlight-push-press.html" data-text="Exercise Spotlight – Push Press - Strength Coach Glasgow" data-count="horizontal"></a></div>
		<div style="clear:both"></div>
	</div>

	
		<div class="blog-comments-bottom">
			
		</div>
	
		<div class="blog-post-separator"></div>
	</div>	<div id="blog-post-191618236231726536" class="blog-post">
	
	
		<div class="blog-header">
			<h2 class="blog-title">
					<a class="blog-title-link blog-link" href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-seated-dumbbell-press">Exercise Spotlight – Seated Dumbbell Press</a>

			</h2>
			<p class="blog-date">
					<span class="date-text">
		5/8/2020
	</span>

			</p>
			<p class="blog-comments">
				
			</p>
		</div>
	
		<div class="blog-separator">&nbsp;</div>
	
		<div class="blog-content">
				
<div><div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0px;margin-right:0px;text-align:center"> <a> <img src="/uploads/1/2/3/3/123320581/exercisespotlightseateddbpress_orig.png" alt="seated dummbell press exercise tutorial by Strength Coach Glasgow Personal Training" style="width:auto;max-width:100%"></a> <div style="display:block;font-size:90%"></div> </div></div>  <div class="paragraph">The seated dumbbell press is a fairly simple exercise but unless you pay close attention, you can put unnecessary pressure in the wrong areas. As you can use the bench upright as a support to set yourself against you can normally lift a little more weight overhead as you take out some of the focus from the core. This is good for getting extra volume through the upper body and shoulders to bring on lagging areas.</div>
<br/>
		<div class="blog-read-more">
			<a href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-seated-dumbbell-press" class="blog-link">Read More</a>
		</div>

		</div>
	
	
			<div class="blog-social  ">
		<div class="blog-social-item blog-fb-like"><fb:like href="https://www.strengthcoachglasgow.co.uk/1/post/2020/05/exercise-spotlight-seated-dumbbell-press.html" width="90" layout="button_count" action="like" show_faces="false" share="false"></fb:like></div><div class="blog-social-item"><a class="twitter-share-button" href="http://twitter.com/share?url=https://www.strengthcoachglasgow.co.uk/1/post/2020/05/exercise-spotlight-seated-dumbbell-press.html" data-text="Exercise Spotlight – Seated Dumbbell Press - Strength Coach Glasgow" data-count="horizontal"></a></div>
		<div style="clear:both"></div>
	</div>

	
		<div class="blog-comments-bottom">
			
		</div>
	
		<div class="blog-post-separator"></div>
	</div>	<div id="blog-post-439660766673734696" class="blog-post">
	
	
		<div class="blog-header">
			<h2 class="blog-title">
					<a class="blog-title-link blog-link" href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-chin-up-negative">Exercise Spotlight – Chin-Up Negative</a>

			</h2>
			<p class="blog-date">
					<span class="date-text">
		5/1/2020
	</span>

			</p>
			<p class="blog-comments">
				
			</p>
		</div>
	
		<div class="blog-separator">&nbsp;</div>
	
		<div class="blog-content">
				
<div><div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center"> <a> <img src="/uploads/1/2/3/3/123320581/exercisespotlightchin-upnegative_orig.png" alt="Picture" style="width:auto;max-width:100%"></a> <div style="display:block;font-size:90%"></div> </div></div>  <div class="paragraph">The Chin-Up Negative is just a variation of the chin-up but it is a great tool for bridging the strength gap to achieve your first Chin-Up. The eccentric portion (or negative) is the lower phase of the lift. Normally we are 20-30% stronger during this phase, you can normally lower under control more than you can lift. If we focus on utilising this extra strength during this portion, we can get stronger overall which can transfer to the pulling up part too! This one requires a decent level of strength already to keep good control and the eccentric phase is the part that makes us sore so expect this one to be really tough and taxing afterwards if you give it a try.<br></div>
<br/>
		<div class="blog-read-more">
			<a href="//www.strengthcoachglasgow.co.uk/blog/exercise-spotlight-chin-up-negative" class="blog-link">Read More</a>
		</div>

		</div>
	
	
			<div class="blog-social  ">
		<div class="blog-social-item blog-fb-like"><fb:like href="https://www.strengthcoachglasgow.co.uk/1/post/2020/05/exercise-spotlight-chin-up-negative.html" width="90" layout="button_count" action="like" show_faces="false" share="false"></fb:like></div><div class="blog-social-item"><a class="twitter-share-button" href="http://twitter.com/share?url=https://www.strengthcoachglasgow.co.uk/1/post/2020/05/exercise-spotlight-chin-up-negative.html" data-text="Exercise Spotlight – Chin-Up Negative - Strength Coach Glasgow" data-count="horizontal"></a></div>
		<div style="clear:both"></div>
	</div>

	
		<div class="blog-comments-bottom">
			
		</div>
	
		<div class="blog-post-separator"></div>
	</div>
	<div class="blog-page-nav-previous">
		<a href="/blog/category/exercises/1" class="blog-link">&lt;&lt;Previous</a>
	</div>


<!-- bid: $blog_id --></div>
	</div>

	    </td>
	        <td class="blog-sidebar" valign="top">
	            <div id="815468006538632597-sidebar" class="column-blog">
	<div class="blog-sidebar-separator">
		<ul id="815468006538632597-sidebar-list" class="columnlist-blog" style="margin:0; padding: 0;">
			<h2 class="blog-author-title">Author</h2>
<p><span style="color:rgb(34, 34, 34)">Allan Young is a Personal Trainer and coach educator in Glasgow who operates Strength Coach Glasgow and is a 4x Scottish Champion Olympic Weightlifter.</span></p>

<h2 class="blog-archives-title">Archives</h2>
<p class="blog-archive-list">
		<a href="/blog/archives/03-2021" class="blog-link">March 2021</a>
		<br />
		<a href="/blog/archives/12-2020" class="blog-link">December 2020</a>
		<br />
		<a href="/blog/archives/07-2020" class="blog-link">July 2020</a>
		<br />
		<a href="/blog/archives/06-2020" class="blog-link">June 2020</a>
		<br />
		<a href="/blog/archives/05-2020" class="blog-link">May 2020</a>
		<br />
		<a href="/blog/archives/04-2020" class="blog-link">April 2020</a>
		<br />
		<a href="/blog/archives/03-2020" class="blog-link">March 2020</a>
		<br />
		<a href="/blog/archives/02-2020" class="blog-link">February 2020</a>
		<br />
		<a href="/blog/archives/01-2020" class="blog-link">January 2020</a>
		<br />
		<a href="/blog/archives/12-2019" class="blog-link">December 2019</a>
		<br />
		<a href="/blog/archives/11-2019" class="blog-link">November 2019</a>
		<br />
		<a href="/blog/archives/10-2019" class="blog-link">October 2019</a>
		<br />
		<a href="/blog/archives/09-2019" class="blog-link">September 2019</a>
		<br />
		<a href="/blog/archives/08-2019" class="blog-link">August 2019</a>
		<br />
		<a href="/blog/archives/07-2019" class="blog-link">July 2019</a>
		<br />
		<a href="/blog/archives/06-2019" class="blog-link">June 2019</a>
		<br />
		<a href="/blog/archives/05-2019" class="blog-link">May 2019</a>
		<br />
		<a href="/blog/archives/04-2019" class="blog-link">April 2019</a>
		<br />
		<a href="/blog/archives/03-2019" class="blog-link">March 2019</a>
		<br />
		<a href="/blog/archives/02-2019" class="blog-link">February 2019</a>
		<br />
		<a href="/blog/archives/01-2019" class="blog-link">January 2019</a>
		<br />
		<a href="/blog/archives/12-2018" class="blog-link">December 2018</a>
		<br />
</p>

<h2 class="blog-category-title">Categories</h2>
<p class="blog-category-list">
	<a href="/blog/category/all" class="blog-link">All</a>
	<br />
		<a href="/blog/category/diet" class="blog-link">Diet</a>
		<br />
		<a href="/blog/category/exercises" class="blog-link">Exercises</a>
		<br />
		<a href="/blog/category/exercise-spotlight" class="blog-link">Exercise Spotlight</a>
		<br />
		<a href="/blog/category/fitness" class="blog-link">Fitness</a>
		<br />
		<a href="/blog/category/goal-setting" class="blog-link">Goal Setting</a>
		<br />
		<a href="/blog/category/gym" class="blog-link">Gym</a>
		<br />
		<a href="/blog/category/home-workout" class="blog-link">Home Workout</a>
		<br />
		<a href="/blog/category/olympic-weightlifting" class="blog-link">Olympic Weightlifting</a>
		<br />
		<a href="/blog/category/personal-trainer-glasgow" class="blog-link">Personal Trainer Glasgow</a>
		<br />
		<a href="/blog/category/review" class="blog-link">Review</a>
		<br />
		<a href="/blog/category/weight-lifting-glasgow" class="blog-link">Weight Lifting Glasgow</a>
		<br />
		<a href="/blog/category/weight-lifting-training" class="blog-link">Weight Lifting Training</a>
		<br />
</p>

<p class="blog-feed-link">
	<link href=""  rel="alternate" type="application/rss+xml" title="RSS" />
	<a href="/1/feed">
		<img src="//cdn2.editmysite.com/images/old/bg_feed.gif" />
		RSS Feed
	</a>
</p>
		</ul>
	</div>
</div>

	        </td>
	</tr>
</table>

</div>
</div>
      </div>
    </div>

    <div class="footer-wrap">
        <div class="footer"><div class='wsite-elements wsite-footer'>
<div><div class="wsite-multicol"><div class="wsite-multicol-table-wrap" style="margin:0 -25px;">
	<table class="wsite-multicol-table">
		<tbody class="wsite-multicol-tbody">
			<tr class="wsite-multicol-tr">
				<td class="wsite-multicol-col" style="width:25.958549304529%; padding:0 25px;">
					
						

<h2 class="wsite-content-title" style="text-align:left;"><font size="4">Services</font></h2>

<div class="paragraph" style="text-align:left;"><a href="/personal-training.html">Strength Foundations<br />Skill Accelerator<br />12 Week Signature Transformation</a><br /><a href="/at-home-personal-training.html">&#8203;Online Personal Training</a><br /></div>


					
				</td>				<td class="wsite-multicol-col" style="width:23.823800184091%; padding:0 25px;">
					
						

<h2 class="wsite-content-title" style="text-align:left;"><font size="4">Learn More</font></h2>

<div class="paragraph" style="text-align:left;"><a href="/about.html">About</a><br /><a href="/blog.html">Blog</a></div>


					
				</td>				<td class="wsite-multicol-col" style="width:50.21765051138%; padding:0 25px;">
					
						

<div><div class="wsite-multicol"><div class="wsite-multicol-table-wrap" style="margin:0 -15px;">
	<table class="wsite-multicol-table">
		<tbody class="wsite-multicol-tbody">
			<tr class="wsite-multicol-tr">
				<td class="wsite-multicol-col" style="width:50.414937759336%; padding:0 15px;">
					
						

<h2 class="wsite-content-title" style="text-align:left;"><font size="4">Support</font></h2>

<div class="paragraph" style="text-align:left;"><a href="/contact.html">Contact</a></div>


					
				</td>				<td class="wsite-multicol-col" style="width:49.585062240664%; padding:0 15px;">
					
						

<h2 class="wsite-content-title" style="text-align:right;">Address</h2>

<div class="paragraph" style="text-align:right;"><font color="#2a2a2a">Private Studio<br />&#8203;Glasgow Southside</font></div>


					
				</td>			</tr>
		</tbody>
	</table>
</div></div></div>


					
				</td>			</tr>
		</tbody>
	</table>
</div></div></div>

<div><div class="wsite-multicol"><div class="wsite-multicol-table-wrap" style="margin:0 -15px;">
	<table class="wsite-multicol-table">
		<tbody class="wsite-multicol-tbody">
			<tr class="wsite-multicol-tr">
				<td class="wsite-multicol-col" style="width:25%; padding:0 15px;">
					
						

<div><div id="536328135925420393" align="right" style="width: 100%; overflow-y: hidden;" class="wcustomhtml"><a href="https://www.bark.com/en/company/strength-coach-glasgow/zYqv/" target="_blank" class="bark-widget" data-type="coe" data-id="zYqv" data-image="small-gold" data-version="2.0">Strength Coach Glasgow</a><script type="text/javascript" src="https://www.bark.com/js/widgets.min.js" defer=""></script></div>



</div>


					
				</td>				<td class="wsite-multicol-col" style="width:25%; padding:0 15px;">
					
						

<div><div id="436863247306046758" align="center" style="width: 100%; overflow-y: hidden;" class="wcustomhtml"><p data-ev=""><a href="https://origympersonaltrainercourses.co.uk/blog/personal-trainer"><img src="https://origympersonaltrainercourses.co.uk/files/img_cache/3506/500_1565610548_Award2.png" width="105" class="img-responsive" alt="best personal trainer in glasgow" /></a></p>
</div>



</div>


					
				</td>				<td class="wsite-multicol-col" style="width:25%; padding:0 15px;">
					
						

<div><div id="943357900159519949" align="center" style="width: 100%; overflow-y: hidden;" class="wcustomhtml"><a href="https://www.instituteofpersonaltrainers.com/code-of-ethical-conduct.html"><img src="https://www.instituteofpersonaltrainers.com/uploads/2/2/0/1/22014694/iptmember3_orig.png" alt=“personal trainer business support” style="width:150px;height:150px;"></a></div>



</div>


					
				</td>				<td class="wsite-multicol-col" style="width:25%; padding:0 15px;">
					
						

<div><div id="295310459253116304" align="center" style="width: 100%; overflow-y: hidden;" class="wcustomhtml"><a href=https://www.insure4sport.co.uk/covertypes/ptandfitnessinstructor/ref=badge><img src=" https://www.insure4sport.co.uk/Content/images/badges/I4S_InsuredBadge_147x124.png" alt="Insure4Sport Personal Trainer Insurance"></a></div>



</div>


					
				</td>			</tr>
		</tbody>
	</table>
</div></div></div>

<div><div style="height: 20px; overflow: hidden; width: 100%;"></div>
<hr class="styled-hr" style="width:100%;"></hr>
<div style="height: 20px; overflow: hidden; width: 100%;"></div></div>

<div><div class="wsite-multicol"><div class="wsite-multicol-table-wrap" style="margin:0 -15px;">
	<table class="wsite-multicol-table">
		<tbody class="wsite-multicol-tbody">
			<tr class="wsite-multicol-tr">
				<td class="wsite-multicol-col" style="width:50%; padding:0 15px;">
					
						

<div class="paragraph" style="text-align:left;"><font size="1">&copy; COPYRIGHT 2020. ALL RIGHTS RESERVED.</font></div>


					
				</td>				<td class="wsite-multicol-col" style="width:50%; padding:0 15px;">
					
						

<div><div id="912742856326153445" align="right" style="width: 100%; overflow-y: hidden;" class="wcustomhtml">Website Design by <a href="https://www.mypersonaltrainerwebsite.com" rel="nofollow">My Personal Trainer Website</a></div>



</div>


					
				</td>			</tr>
		</tbody>
	</table>
</div></div></div></div></div>
    </div><!-- end footer-wrap -->
  </div><!-- /.wrapper -->

  <div id="navMobile" class="nav mobile-nav">
    <a class="hamburger" aria-label="Menu" href="#"><span></span></a>
    <ul class="wsite-menu-default">
    		<li id="pg819301532588520220" class="wsite-menu-item-wrap">
    			<a
    						href="/"
    				class="wsite-menu-item"
    				>
    				Home
    			</a>
    			
    		</li>
    		<li id="pg563831931702132542" class="wsite-menu-item-wrap">
    			<a
    						href="/about.html"
    				class="wsite-menu-item"
    				>
    				About
    			</a>
    			
    		</li>
    		<li id="pg212032923499255978" class="wsite-menu-item-wrap">
    			<a
    				class="wsite-menu-item"
    				>
    				Programs
    			</a>
    			<div class="wsite-menu-wrap" style="display:none">
	<ul class="wsite-menu">
		<li id="wsite-nav-876530741345501780"
	class="wsite-menu-subitem-wrap "
	>
	<a
				href="/personal-training.html"
		class="wsite-menu-subitem"
		>
		<span class="wsite-menu-title">
			Personal Training
		</span>
	</a>
	
</li>
<li id="wsite-nav-462203199864741067"
	class="wsite-menu-subitem-wrap "
	>
	<a
				href="/online-training.html"
		class="wsite-menu-subitem"
		>
		<span class="wsite-menu-title">
			Online Training
		</span>
	</a>
	
</li>

	</ul>
</div>

    		</li>
    		<li id="pg495204845769764285" class="wsite-menu-item-wrap">
    			<a
    						href="/success-stories.html"
    				class="wsite-menu-item"
    				>
    				Success Stories
    			</a>
    			
    		</li>
    		<li id="pg166172616511975132" class="wsite-menu-item-wrap">
    			<a
    						href="/contact.html"
    				class="wsite-menu-item"
    				>
    				Contact
    			</a>
    			
    		</li>
    		<li id="active" class="wsite-menu-item-wrap">
    			<a
    						href="/blog.html"
    				class="wsite-menu-item"
    				>
    				Blog
    			</a>
    			
    		</li>
    </ul>
  </div>

	<script type="text/javascript" src="/files/theme/plugins.js"></script>
  <script type="text/javascript" src="/files/theme/custom.js"></script>
    <div id="customer-accounts-app"></div>
    <script src="//cdn2.editmysite.com/js/site/main-customer-accounts-site.js?buildTime=1640035830"></script>

		<script type="text/javascript">
	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', 'UA-7870337-1']);
	_gaq.push(['_setDomainName', 'none']);
	_gaq.push(['_setAllowLinker', true]);

	(function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		// NOTE: keep the [1] if you replace this code. Otherwise cookie banner scripts won't be first on the page
		var s = document.getElementsByTagName('script')[1]; s.parentNode.insertBefore(ga, s);
	})();

	_W.Analytics = _W.Analytics || {'trackers': {}};
	_W.Analytics.trackers.wGA = '_gaq';
</script>

<script type="text/javascript" async=1>
	// NOTE: keep the getElementsByTagName(o)**[1]** if you replace this code. Otherwise cookie banner scripts won't be first on the page
	;(function(p,l,o,w,i,n,g){if(!p[i]){p.GlobalSnowplowNamespace=p.GlobalSnowplowNamespace||[];
			p.GlobalSnowplowNamespace.push(i);p[i]=function(){(p[i].q=p[i].q||[]).push(arguments)
			};p[i].q=p[i].q||[];n=l.createElement(o);g=l.getElementsByTagName(o)[1];n.async=1;
			n.src=w;g.parentNode.insertBefore(n,g)}}(window,document,'script','//cdn2.editmysite.com/js/wsnbn/snowday262.js','snowday'));

	var r = [99, 104, 101, 99, 107, 111, 117, 116, 46, 40, 119, 101, 101, 98, 108, 121, 124, 101, 100, 105, 116, 109, 121, 115, 105, 116, 101, 41, 46, 99, 111, 109];
	var snPlObR = function(arr) {
		var s = '';
		for (var i = 0 ; i < arr.length ; i++){
			s = s + String.fromCharCode(arr[i]);
		}
		return s;
	};
	var s = snPlObR(r);

	var regEx = new RegExp(s);

	_W.Analytics = _W.Analytics || {'trackers': {}};
	_W.Analytics.trackers.wSP = 'snowday';
	_W.Analytics.user_id = '123320581';
	_W.Analytics.site_id = '540203683522207150';

	var drSegmentsTag = document.getElementById('drSegments');
	if (drSegmentsTag) {
		_W.Analytics.spContexts = _W.Analytics.spContexts || [];

		var segmentData = JSON.parse(drSegmentsTag.innerText);
		segmentData.forEach(function(test) {
			_W.Analytics.spContexts.push({
				schema: "iglu:com.weebly/context_ab_segment/jsonschema/1-0-0",
				data: {
					test_id: test.name,
					segment: test.variant,
				}
			});
		});
	}


	(function(app_id, ec_hostname, discover_root_domain) {
		var track = window[_W.Analytics.trackers.wSP];
		if (!track) return;
		track('newTracker', app_id, ec_hostname, {
			appId: app_id,
			post: true,
			platform: 'web',
			discoverRootDomain: discover_root_domain,
			cookieName: '_snow_',
			contexts: {
				webPage: true,
				performanceTiming: true,
				gaCookies: true
			},
			crossDomainLinker: function (linkElement) {
				return regEx.test(linkElement.href);
			},
			respectDoNotTrack: true
		});
		track('trackPageView', _W.Analytics.user_id+':'+_W.Analytics.site_id, _W.Analytics.spContexts);
		track('crossDomainLinker', function (linkElement) {
			return regEx.test(linkElement.href);
		});
	})(
		'_wn',
		'ec.editmysite.com',
		true
	);
</script>





<script>
	(function(jQuery) {
		try {
			if (jQuery) {
				jQuery('div.blog-social div.fb-like').attr('class', 'blog-social-item blog-fb-like');
				var $commentFrame = jQuery('#commentArea iframe');
				if ($commentFrame.length > 0) {
					var frameHeight = jQuery($commentFrame[0].contentWindow.document).height() + 50;
					$commentFrame.css('min-height', frameHeight + 'px');
				}
				if (jQuery('.product-button').length > 0){
					jQuery(document).ready(function(){
						jQuery('.product-button').parent().each(function(index, product){
							if(jQuery(product).attr('target') == 'paypal'){
								if (!jQuery(product).find('> [name="bn"]').length){
									jQuery('<input>').attr({
										type: 'hidden',
										name: 'bn',
										value: 'DragAndDropBuil_SP_EC'
									}).appendTo(product);
								}
							}
						});
					});
				}
			}
			else {
				// Prototype
				$$('div.blog-social div.fb-like').each(function(div) {
					div.className = 'blog-social-item blog-fb-like';
				});
				$$('#commentArea iframe').each(function(iframe) {
					iframe.style.minHeight = '410px';
				});
			}
		}
		catch(ex) {}
	})(window._W && _W.jQuery);
</script>

<script>
	window._W.isEUUser = false;
	window._W.showCookieToAll = "";
</script>

<div id="fb-root"></div>
<script>
	window.fbAsyncInit = function() {
		FB.init({
			appId : '190291501407',
			xfbml : true,
			version : 'v2.6'
		});

        // Set Facebook comment plugin's colorscheme based off of theme
		var comments = document.getElementsByClassName('facebook-comment-widget'),
			scheme = document.body.className.match('wsite-theme-light');

		for (var i = 0; i < comments.length; i++) {
			comments[i].setAttribute('colorscheme', scheme ? 'light' : 'dark');
		}

		var fbCommentCounts;

		FB.Event.subscribe('xfbml.render', function(){
			fbCommentCounts = jQuery('.fb_comments_count');
			for (var i = 0; i < fbCommentCounts.length; i++) {
				var commentText = (jQuery(fbCommentCounts[i]).text() == '1' ? "Comment" : "Comments");
				jQuery(fbCommentCounts[i]).parent().siblings('.fb_comment_count_label').text(commentText);
			}
		});

		var comment_callback = function(res) {
			FB.XFBML.parse(); // Refresh comment counters on page
		}

		FB.Event.subscribe('comment.create', comment_callback);
		FB.Event.subscribe('comment.remove', comment_callback);

	};

	(function(d, s, id){
		var js, fjs = d.getElementsByTagName(s)[0];
		if (d.getElementById(id)) {return;}
		js = d.createElement(s); js.id = id;
		js.src = "//connect.facebook.net/"+_W.facebookLocale+"/sdk.js";
		fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));
</script>
<script type='text/javascript'>
	(function() {
		function j(src, id) {
			var s = document.createElement('script');
			s.type = 'text/javascript';
			s.async = true;
			s.src = src;
			if(id) {s.id=id};
			document.getElementsByTagName('head')[0].appendChild(s);
		}
		j('//platform.twi'+'tter.com/widgets.js');
	})()
</script>
	</body>
</html>
